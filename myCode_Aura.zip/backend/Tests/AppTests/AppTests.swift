@testable import App
import XCTVapor

final class AppTests: XCTestCase {
    
}
